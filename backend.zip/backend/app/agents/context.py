from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class AgentContext:
    """
    Shared context available to ECHO agents during a workflow.

    The Coordinator owns the workflow and progressively enriches
    this context with agent results.
    """

    user: Optional[Any] = None

    current_state: Optional[Any] = None

    recent_memories: List[Any] = field(default_factory=list)

    memory_analysis: Optional[Any] = None

    goals: List[Any] = field(default_factory=list)

    planner_tasks: List[Any] = field(default_factory=list)

    insights: List[Any] = field(default_factory=list)

    snapshots: List[Any] = field(default_factory=list)

    trends: Optional[Any] = None

    simulation: Optional[Any] = None

    metadata: Dict[str, Any] = field(default_factory=dict)

    # Results produced during the current workflow.
    agent_results: Dict[str, Any] = field(default_factory=dict)

    def store_result(self, agent_name: str, result: Any) -> None:
        """
        Store an agent's result in the shared workflow context.
        """

        self.agent_results[agent_name] = result

    def get_result(self, agent_name: str) -> Optional[Any]:
        """
        Retrieve a previous agent's result.
        """

        return self.agent_results.get(agent_name)
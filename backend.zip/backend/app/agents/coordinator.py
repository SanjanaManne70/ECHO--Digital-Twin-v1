from typing import Dict, List

from .context import AgentContext
from .registry import AgentRegistry
from .result import AgentResult


class Coordinator:
    """
    Central orchestration layer for ECHO V2.

    The Coordinator determines which agents participate in a workflow,
    executes them in order, and progressively enriches the shared
    AgentContext with their results.
    """

    def __init__(self, registry: AgentRegistry):
        self.registry = registry

    def run(
        self,
        context: AgentContext,
        workflow: List[str],
    ) -> Dict[str, AgentResult]:
        """
        Execute the requested agent workflow.

        Each agent receives the same shared AgentContext object.
        After execution, its result is stored inside that context,
        making the result available to subsequent agents.
        """

        results: Dict[str, AgentResult] = {}

        for agent_name in workflow:

            agent = self.registry.get(agent_name)

            result = agent.run(context)

            results[agent_name] = result

            context.store_result(
                agent_name=agent_name,
                result=result,
            )

        return results
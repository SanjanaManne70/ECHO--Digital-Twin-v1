from app.agents import (
    AgentContext,
    AgentRegistry,
    AgentResult,
    BaseAgent,
)


class TestAgent(BaseAgent):

    name = "test"

    def run(self, context: AgentContext) -> AgentResult:
        return AgentResult(
            success=True,
            agent_name=self.name,
            data={
                "message": "Agent foundation works"
            },
        )


def test_agent_context():
    context = AgentContext()

    assert context.current_state is None
    assert context.recent_memories == []
    assert context.goals == []


def test_agent_result():
    result = AgentResult(
        success=True,
        agent_name="test",
        data={"value": 123},
    )

    assert result.success is True
    assert result.agent_name == "test"
    assert result.data["value"] == 123


def test_agent_registry():

    registry = AgentRegistry()

    agent = TestAgent()

    registry.register(agent)

    assert registry.has("test")

    retrieved = registry.get("test")

    assert retrieved is agent

    assert "test" in registry.list_agents()


def test_agent_execution():

    agent = TestAgent()

    context = AgentContext()

    result = agent.run(context)

    assert result.success is True
    assert result.agent_name == "test"
    assert result.data["message"] == "Agent foundation works"
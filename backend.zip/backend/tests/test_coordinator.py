from app.agents import (
    AgentContext,
    AgentRegistry,
    AgentResult,
    BaseAgent,
    Coordinator,
)


class TestAgentA(BaseAgent):

    name = "agent_a"

    def run(self, context: AgentContext) -> AgentResult:
        return AgentResult(
            success=True,
            agent_name=self.name,
            data={
                "value": 100
            },
        )


class TestAgentB(BaseAgent):

    name = "agent_b"

    def run(self, context: AgentContext) -> AgentResult:

        previous_result = context.get_result("agent_a")

        previous_value = previous_result.data["value"]

        return AgentResult(
            success=True,
            agent_name=self.name,
            data={
                "received_value": previous_value,
                "value": previous_value + 50,
            },
        )


def test_coordinator_executes_workflow():

    registry = AgentRegistry()

    registry.register(TestAgentA())
    registry.register(TestAgentB())

    coordinator = Coordinator(registry)

    context = AgentContext()

    results = coordinator.run(
        context=context,
        workflow=[
            "agent_a",
            "agent_b",
        ],
    )

    assert "agent_a" in results
    assert "agent_b" in results

    assert results["agent_a"].success is True
    assert results["agent_b"].success is True


def test_agent_results_are_propagated():

    registry = AgentRegistry()

    registry.register(TestAgentA())
    registry.register(TestAgentB())

    coordinator = Coordinator(registry)

    context = AgentContext()

    coordinator.run(
        context=context,
        workflow=[
            "agent_a",
            "agent_b",
        ],
    )

    # Agent A's result should be stored.
    assert context.get_result("agent_a") is not None

    # Agent B should have received Agent A's result.
    agent_b_result = context.get_result("agent_b")

    assert agent_b_result is not None

    assert agent_b_result.data["received_value"] == 100

    assert agent_b_result.data["value"] == 150
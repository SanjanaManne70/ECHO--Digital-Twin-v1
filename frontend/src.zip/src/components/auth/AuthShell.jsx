import ParticleField from "./ParticleField";
import TwinPortrait from "./TwinPortrait";
import EchoLogo from "../brand/EchoLogo";

/** Cinematic split-screen brand layout shared by the authentication screens. */
export default function AuthShell({ heading, subheading, children }) {
  return (
    <main className="auth-scene relative isolate min-h-dvh overflow-hidden bg-ink-950 text-white">
      <div aria-hidden="true" className="auth-ambient absolute inset-0 -z-20" />
      <div aria-hidden="true" className="auth-vignette pointer-events-none absolute inset-0 -z-10" />
      <ParticleField className="-z-10 opacity-75" />

      <div className="auth-grid relative mx-auto grid min-h-dvh w-full max-w-[1920px] lg:grid-cols-[1.12fr_.88fr]">
        <section aria-label="The ECHO digital twin" className="auth-art relative order-1 flex min-h-[310px] items-center justify-center px-1 pb-1 pt-5 sm:min-h-[390px] sm:px-3 lg:min-h-dvh lg:px-0 lg:py-4">
          <div aria-hidden="true" className="auth-art-orb" />
          <TwinPortrait className="auth-twin relative z-10 h-auto w-full max-h-none sm:max-h-none lg:max-h-[92vh]" />
          <div aria-hidden="true" className="auth-art-caption hidden lg:block">
            <span className="auth-caption-line" />
            <span>MEMORY · PATTERN · POSSIBILITY</span>
          </div>
        </section>

        <section className="auth-panel relative order-2 flex items-center justify-center px-5 pb-10 pt-4 sm:px-8 lg:min-h-dvh lg:px-12 lg:py-12 xl:px-20">
          <div className="auth-panel-glow" aria-hidden="true" />
          <div className="auth-content stagger relative z-10 w-full max-w-[430px]">
            <header style={{ "--i": 1 }} className="mb-7 text-center lg:mb-9">
              <div className="mb-1 flex justify-center lg:justify-start">
                <EchoLogo size="lg" className="auth-wordmark" />
              </div>
              <p className="mt-3 text-[10px] font-semibold uppercase tracking-[0.42em] text-signal-cyan sm:text-xs">
                Your digital twin
              </p>
              <p className="mx-auto mt-4 max-w-[330px] text-sm leading-6 text-slate-400 sm:text-[15px] lg:mx-0">
                Your experiences today,<br className="hidden sm:block" /> <span className="text-slate-200">a better you tomorrow.</span>
              </p>
            </header>

            <div style={{ "--i": 2 }} className="auth-card glass relative rounded-[26px] p-5 sm:p-8">
              <div aria-hidden="true" className="auth-card-edge" />
              <div className="relative z-10">
                <div className="mb-6">
                  <h1 className="font-display text-xl font-semibold tracking-tight text-white sm:text-2xl">{heading}</h1>
                  {subheading && <p className="mt-2 text-sm leading-6 text-slate-400">{subheading}</p>}
                </div>
                {children}
              </div>
            </div>

            <p className="mt-6 text-center text-[11px] text-slate-600">
              ECHO V2 <span className="mx-2 text-slate-700">•</span> A more personal kind of intelligence
            </p>
          </div>
        </section>
      </div>
    </main>
  );
}
